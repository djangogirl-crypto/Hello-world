package Pack;

import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Return_Book extends JFrame {

	private JPanel contentPane;
	private JTextField bookcallno;
	private JTextField studid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Return_Book frame = new Return_Book();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn = null;
	/**
	 * Create the frame.
	 */
	public Return_Book() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650,500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblreturnbook = new JLabel("Return Book");
		lblreturnbook.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblreturnbook.setBounds(217, 32, 156, 25);
		contentPane.add(lblreturnbook);
		
		JLabel lblbookcallno = new JLabel("Book Call No");
		lblbookcallno.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblbookcallno.setBounds(89, 117, 115, 25);
		contentPane.add(lblbookcallno);
		
		JLabel lblstudentID = new JLabel("Student ID");
		lblstudentID.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblstudentID.setBounds(89, 175, 92, 36);
		contentPane.add(lblstudentID);
		
		bookcallno = new JTextField();
		bookcallno.setBounds(254, 117, 146, 24);
		contentPane.add(bookcallno);
		bookcallno.setColumns(10);
		
		studid = new JTextField();
		studid.setBounds(254, 181, 146, 24);
		contentPane.add(studid);
		studid.setColumns(10);
		
		JButton btnreturnbook = new JButton("Return Book");
		btnreturnbook.setForeground(new Color(255, 255, 255));
		btnreturnbook.setBackground(new Color(0, 0, 128));
		btnreturnbook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
					conn = Connector.dbConnector();
					String query="DELETE FROM issue_books WHERE book_callno=? and student_id=?";
					PreparedStatement pst = conn.prepareStatement(query);
					pst.setString(1,bookcallno.getText());
					pst.setInt(2,Integer.parseInt(studid.getText()));
					pst.executeUpdate();
					JOptionPane.showMessageDialog(btnreturnbook,"Book returned successfully");
					pst.close();
					conn.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(btnreturnbook,"Can't return book due to wrong id or callno");
				}
				finally
				{
					try 
					{
						conn=Connector.dbConnector();
						Statement st = conn.createStatement();
						String query="SELECT * FROM book_details";
						ResultSet rs = st.executeQuery(query);
						String val;
						while(rs.next())
						{
							val=rs.getString("callno");
							if(val.equals(bookcallno.getText()))
							{
								int quantity=rs.getInt("quantity");
								int issued = rs.getInt("issued");
								if(quantity>=0)
								{
									int remaining=quantity+1;
									try
									{
										String query2="UPDATE book_details SET issued=?,quantity=? WHERE callno=?";
										PreparedStatement ps = conn.prepareStatement(query2);
										ps.setInt(1,issued-1);
										ps.setInt(2,remaining);
										ps.setString(3,val);
										ps.executeUpdate();
										JOptionPane.showMessageDialog(btnreturnbook,"Updated data");
										ps.close();
										conn.close();
									}
									catch(Exception e3)
									{
										JOptionPane.showMessageDialog(btnreturnbook,"Can't update");
									}
								}
							}
						}
						rs.close();
						st.close();
						conn.close();
					}
					catch(Exception e2)
					{
						//System.out.println("");
						//JOptionPane.showMessageDialog(btnreturnbook,"Some error in updating data");
					}
				}
			}
		});
		btnreturnbook.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnreturnbook.setBounds(205, 266, 168, 36);
		contentPane.add(btnreturnbook);
		
		JButton btnback = new JButton("Back");
		btnback.setForeground(new Color(255, 255, 255));
		btnback.setBackground(new Color(0, 0, 128));
		btnback.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Librarian_Block lb = new Librarian_Block();
				lb.setVisible(true);
			}
		});
		btnback.setBounds(447, 382, 85, 36);
		contentPane.add(btnback);
	}
}
