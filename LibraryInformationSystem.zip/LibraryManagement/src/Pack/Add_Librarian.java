package Pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Add_Librarian extends JFrame {

	private JPanel contentPane;
	private JTextField textname;
	private JPasswordField textpass;
	private JTextField textemail;
	private JTextField textaddress;
	private JTextField textcity;
	private JTextField textcontact;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Librarian frame = new Add_Librarian();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn = null;
	private JTextField textid;
	/**
	 * Create the frame.
	 */
	public Add_Librarian() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650,500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add Librarian");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(225, 10, 155, 25);
		contentPane.add(lblNewLabel);
		
		JLabel name = new JLabel("Name");
		name.setFont(new Font("Tahoma", Font.BOLD, 15));
		name.setBounds(79, 95, 97, 25);
		contentPane.add(name);
		
		JLabel password = new JLabel("Password");
		password.setFont(new Font("Tahoma", Font.BOLD, 15));
		password.setBounds(79, 141, 96, 25);
		contentPane.add(password);
		
		JLabel email = new JLabel("Email");
		email.setFont(new Font("Tahoma", Font.BOLD, 15));
		email.setBounds(79, 190, 82, 25);
		contentPane.add(email);
		
		JLabel address = new JLabel("Address");
		address.setFont(new Font("Tahoma", Font.BOLD, 15));
		address.setBounds(79, 240, 97, 31);
		contentPane.add(address);
		
		JLabel city = new JLabel("City");
		city.setFont(new Font("Tahoma", Font.BOLD, 15));
		city.setBounds(79, 288, 71, 25);
		contentPane.add(city);
		
		JLabel contact = new JLabel("Contact No");
		contact.setFont(new Font("Tahoma", Font.BOLD, 15));
		contact.setBounds(79, 335, 125, 25);
		contentPane.add(contact);
		
		textname = new JTextField();
		textname.setBounds(225, 95, 180, 24);
		contentPane.add(textname);
		textname.setColumns(10);
		
		textpass = new JPasswordField();
		textpass.setBounds(225, 141, 180, 24);
		contentPane.add(textpass);
		
		textemail = new JTextField();
		textemail.setBounds(225, 190, 180, 24);
		contentPane.add(textemail);
		textemail.setColumns(10);
		
		textaddress = new JTextField();
		textaddress.setBounds(225, 240, 180, 27);
		contentPane.add(textaddress);
		textaddress.setColumns(10);
		
		textcity = new JTextField();
		textcity.setBounds(225, 288, 180, 24);
		contentPane.add(textcity);
		textcity.setColumns(10);
		
		textcontact = new JTextField();
		textcontact.setBounds(225, 335, 180, 24);
		contentPane.add(textcontact);
		textcontact.setColumns(10);
		
		JButton AddLibrarian = new JButton("Add Librarian");
		AddLibrarian.setForeground(new Color(255, 255, 255));
		AddLibrarian.setBackground(new Color(0, 0, 128));
		AddLibrarian.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conn=Connector.dbConnector();
				try {
					String query="INSERT INTO librarians VALUES(?,?,?,?,?,?,?)";
					PreparedStatement pst = conn.prepareStatement(query);
					pst.setString(1,textid.getText());
					pst.setString(2,textname.getText());
					pst.setString(3,textpass.getText());
					pst.setString(4,textemail.getText());
					pst.setString(5,textaddress.getText());
					pst.setString(6,textcity.getText());
					pst.setString(7,textcontact.getText());
					//ResultSet rs = pst.executeQuery();
					int count = pst.executeUpdate();
					JOptionPane.showMessageDialog(AddLibrarian,"Librarian Added Successfully");
					pst.close();
					conn.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(AddLibrarian,"Cannot add any row!!");
				}
			}
		});
		AddLibrarian.setFont(new Font("Tahoma", Font.BOLD, 15));
		AddLibrarian.setBounds(132, 395, 146, 41);
		contentPane.add(AddLibrarian);
		
		JButton Back = new JButton("Back");
		Back.setForeground(new Color(255, 255, 255));
		Back.setBackground(new Color(0, 0, 128));
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Admin_Block ab = new Admin_Block();
				ab.setVisible(true);
			}
		});
		Back.setFont(new Font("Tahoma", Font.BOLD, 15));
		Back.setBounds(368, 395, 146, 41);
		contentPane.add(Back);
		
		JLabel Librarian_id = new JLabel("Librarian ID");
		Librarian_id.setFont(new Font("Tahoma", Font.BOLD, 15));
		Librarian_id.setBounds(79, 53, 97, 25);
		contentPane.add(Librarian_id);
		
		textid = new JTextField();
		textid.setBounds(224, 58, 181, 25);
		contentPane.add(textid);
		textid.setColumns(10);
	}

}

