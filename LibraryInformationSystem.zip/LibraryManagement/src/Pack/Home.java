package Pack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setBounds(100, 100,650,500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLibrary = new JLabel("Library Information System");
		lblLibrary.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblLibrary.setBounds(185, 38, 384, 60);
		frame.getContentPane().add(lblLibrary);
		
		JButton btnadmin = new JButton("Admin");
		btnadmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Admin_Login al = new Admin_Login();
				al.setVisible(true);
			}
		});
		btnadmin.setBackground(new Color(0, 0, 128));
		btnadmin.setForeground(SystemColor.text);
		btnadmin.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnadmin.setBounds(250, 170, 142, 45);
		frame.getContentPane().add(btnadmin);
		
		JButton btnlibrarian = new JButton("Librarian");
		btnlibrarian.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Librarian_Login ll = new Librarian_Login();
				ll.setVisible(true);
			}
		});
		btnlibrarian.setForeground(new Color(255, 255, 255));
		btnlibrarian.setBackground(new Color(0, 0, 128));
		btnlibrarian.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnlibrarian.setBounds(250, 256, 142, 45);
		frame.getContentPane().add(btnlibrarian);
		
		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Home-icon.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(10, 23, 121, 100);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Main Page");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Main m = new Main();
				m.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 0, 128));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(459, 380, 121, 39);
		frame.getContentPane().add(btnNewButton);
	}
}
