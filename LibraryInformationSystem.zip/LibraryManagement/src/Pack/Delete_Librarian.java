package Pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Delete_Librarian extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delete_Librarian frame = new Delete_Librarian();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Delete_Librarian() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDellib = new JLabel("Delete Librarian");
		lblDellib.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblDellib.setBounds(202, 35, 185, 34);
		contentPane.add(lblDellib);
		
		JLabel lbliddel = new JLabel("Enter ID");
		lbliddel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lbliddel.setBounds(146, 136, 105, 27);
		contentPane.add(lbliddel);
		
		textField = new JTextField();
		textField.setBounds(246, 138, 216, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btndelete = new JButton("Delete");
		btndelete.setForeground(new Color(255, 255, 255));
		btndelete.setBackground(new Color(0, 0, 128));
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection conn = Connector.dbConnector();
				try 
				{
					String query="DELETE FROM librarians where librarian_id=?";
					PreparedStatement pst = conn.prepareStatement(query);
					pst.setLong(1,Integer.parseInt(textField.getText()));
					int count = pst.executeUpdate();
					JOptionPane.showMessageDialog(btndelete,"Record Deleted Successfully");
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(btndelete,"Cannot delete the row");
				}
			}
		});
		btndelete.setFont(new Font("Tahoma", Font.BOLD, 15));
		btndelete.setBounds(226, 230, 119, 34);
		contentPane.add(btndelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(new Color(255, 255, 255));
		btnBack.setBackground(new Color(0, 0, 128));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Admin_Block ab = new Admin_Block();
				ab.setVisible(true);
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnBack.setBounds(226, 306, 119, 34);
		contentPane.add(btnBack);
	}

}
