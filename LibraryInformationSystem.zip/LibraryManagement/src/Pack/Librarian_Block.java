package Pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Librarian_Block extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Librarian_Block frame = new Librarian_Block();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Librarian_Block() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650,500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLibrarianSection = new JLabel("Librarian Section");
		lblLibrarianSection.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblLibrarianSection.setBounds(232, 25, 171, 30);
		contentPane.add(lblLibrarianSection);
		
		JButton btnAddBooks = new JButton("Add Books");
		btnAddBooks.setForeground(new Color(255, 255, 255));
		btnAddBooks.setBackground(new Color(0, 0, 128));
		btnAddBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Add_Book ab = new Add_Book();
				ab.setVisible(true);
			}
		});
		btnAddBooks.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAddBooks.setBounds(221, 88, 199, 35);
		contentPane.add(btnAddBooks);
		
		JButton btnViewBooks = new JButton("View Books");
		btnViewBooks.setForeground(new Color(255, 255, 255));
		btnViewBooks.setBackground(new Color(0, 0, 128));
		btnViewBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				View_Books vb = new View_Books();
				vb.setVisible(true);
			}
		});
		btnViewBooks.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewBooks.setBounds(221, 146, 199, 35);
		contentPane.add(btnViewBooks);
		
		JButton btnIssueBook = new JButton("Issue Book");
		btnIssueBook.setForeground(new Color(255, 255, 255));
		btnIssueBook.setBackground(new Color(0, 0, 128));
		btnIssueBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Issue_Book ib = new Issue_Book();
				ib.setVisible(true);
			}
		});
		btnIssueBook.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnIssueBook.setBounds(221, 205, 199, 35);
		contentPane.add(btnIssueBook);
		
		JButton btnViewIssuedBooks = new JButton("View Issued Books");
		btnViewIssuedBooks.setForeground(new Color(255, 255, 255));
		btnViewIssuedBooks.setBackground(new Color(0, 0, 128));
		btnViewIssuedBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				View_Issued_Books vib = new View_Issued_Books();
				vib.setVisible(true);
			}
		});
		btnViewIssuedBooks.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewIssuedBooks.setBounds(221, 269, 199, 35);
		contentPane.add(btnViewIssuedBooks);
		
		JButton btnReturnBook = new JButton("Return Book");
		btnReturnBook.setForeground(new Color(255, 255, 255));
		btnReturnBook.setBackground(new Color(0, 0, 128));
		btnReturnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Return_Book rb = new Return_Book();
				rb.setVisible(true);
			}
		});
		btnReturnBook.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnReturnBook.setBounds(221, 329, 199, 35);
		contentPane.add(btnReturnBook);
		
		JButton btnLogin = new JButton("Logout");
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setBackground(new Color(0, 0, 128));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Home h = new Home();
				h.main(null);
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLogin.setBounds(221, 388, 199, 35);
		contentPane.add(btnLogin);
	}

}

