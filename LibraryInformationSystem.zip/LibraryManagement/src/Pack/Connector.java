package Pack;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class Connector {
	static Connection con = null;
	;	public static Connection dbConnector()
		{
			try 
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","mysql@123");
				//JOptionPane.showMessageDialog(null,"Connected to Database Successfully");
				return con;
			}
			catch(Exception e) 
			{
				JOptionPane.showMessageDialog(null,"Could not connect to Database");
				return null;
			}
		}
}
