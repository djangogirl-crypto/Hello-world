package Pack;

import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;   
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

//import sun.jvm.hotspot.tools.PStack;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.awt.SystemColor;
import java.awt.Color;
public class Issue_Book extends JFrame {

	private JPanel contentPane;
	private JTextField textcallno;
	private JTextField textid;
	private JTextField textname;
	private JTextField textcontact;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Issue_Book frame = new Issue_Book();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn = null;
	/**
	 * Create the frame.
	 */
	public Issue_Book() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650,500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIssueBook = new JLabel("Issue Book");
		lblIssueBook.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblIssueBook.setBounds(238, 10, 141, 36);
		contentPane.add(lblIssueBook);
		
		JLabel lblbookcallno = new JLabel("Book Call No");
		lblbookcallno.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblbookcallno.setBounds(95, 77, 112, 43);
		contentPane.add(lblbookcallno);
		
		JLabel lblstudentid = new JLabel("Student ID");
		lblstudentid.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblstudentid.setBounds(95, 143, 112, 25);
		contentPane.add(lblstudentid);
		
		JLabel lblstudentname = new JLabel("Student Name");
		lblstudentname.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblstudentname.setBounds(95, 196, 112, 25);
		contentPane.add(lblstudentname);
		
		JLabel lblstudentcontact = new JLabel("Student Contact");
		lblstudentcontact.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblstudentcontact.setBounds(95, 250, 124, 25);
		contentPane.add(lblstudentcontact);
		
		textcallno = new JTextField();
		textcallno.setBounds(268, 85, 175, 25);
		contentPane.add(textcallno);
		textcallno.setColumns(10);
		
		textid = new JTextField();
		textid.setBounds(268, 143, 175, 24);
		contentPane.add(textid);
		textid.setColumns(10);
		
		textname = new JTextField();
		textname.setBounds(268, 196, 175, 24);
		contentPane.add(textname);
		textname.setColumns(10);
		
		textcontact = new JTextField();
		textcontact.setBounds(268, 250, 175, 24);
		contentPane.add(textcontact);
		textcontact.setColumns(10);
		
		JButton btnIssueBook = new JButton("Issue Book");
		btnIssueBook.setForeground(new Color(255, 255, 255));
		btnIssueBook.setBackground(new Color(0, 0, 128));
		btnIssueBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{ 
					//int count=0;
					conn=Connector.dbConnector();
					Statement st = conn.createStatement();
					String query="SELECT * FROM book_details";
					ResultSet rs = st.executeQuery(query);
					String val;
					while(rs.next())
					{
						val=rs.getString("callno");
						if(val.equals(textcallno.getText()))
						{
							int quantity=rs.getInt("quantity");
							int issued = rs.getInt("issued");
							//System.out.println(quantity + " "+issued);
							if(quantity>0)
							{
								int remaining=quantity-1;
								try
								{
									String query2="UPDATE book_details SET issued=?,quantity=? WHERE callno=?";
									PreparedStatement ps = conn.prepareStatement(query2);
									ps.setInt(1,issued+1);
									ps.setInt(2,remaining);
									ps.setString(3,val);
									ps.executeUpdate();
									//System.out.println("Updated data");
									JOptionPane.showMessageDialog(btnIssueBook,"Book issued successfully");
								}
								catch(Exception e3)
								{
									JOptionPane.showMessageDialog(btnIssueBook,"Can't issue the book");
								}
								//System.out.println(remaining+" books are available");
							}
							else
							{
								JOptionPane.showMessageDialog(btnIssueBook,"Book cannot be issued");
							}
						}
					}
					//JOptionPane.showMessageDialog(btnIssueBook,"Connected to database");
					//JOptionPane.showMessageDialog(btnIssueBook,count+"rows are present");
					st.close();
					rs.close();
					conn.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(btnIssueBook,"Oops couldn't connect to database");
				}
				finally
				{
				conn=Connector.dbConnector();
				int records=0;
				try {
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
					LocalDateTime now = LocalDateTime.now(); 
					String query3="SELECT * FROM issue_books";
					Statement s = conn.createStatement();
					ResultSet rst = s.executeQuery(query3);
					while(rst.next())
					{
						records++;
					}
					try {
					String query4="INSERT INTO issue_books VALUES(?,?,?,?,?,?)";
					PreparedStatement pst = conn.prepareStatement(query4);
					pst.setInt(1,records+1);
					pst.setString(2,textcallno.getText());
					pst.setInt(3,Integer.parseInt(textid.getText()));
					pst.setString(4,textname.getText());
					pst.setString(5,textcontact.getText());
					pst.setString(6,dtf.format(now));
					int row=pst.executeUpdate();
					JOptionPane.showMessageDialog(btnIssueBook,"Data Updated");
					pst.close();
					conn.close();
					}
					catch(Exception e4)
					{
						JOptionPane.showMessageDialog(btnIssueBook,"Data can't be added");
					}
				}
				catch(Exception e2)
				{
					JOptionPane.showMessageDialog(btnIssueBook,"Data cannot be added now");
				} 
				}
			}
		}
		);
		
		btnIssueBook.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnIssueBook.setBounds(241, 329, 124, 36);
		contentPane.add(btnIssueBook);
		
		JButton btnback = new JButton("Back");
		btnback.setForeground(new Color(255, 255, 255));
		btnback.setBackground(new Color(0, 0, 128));
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Librarian_Block lb = new Librarian_Block();
				lb.setVisible(true);
			}
		});
		btnback.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnback.setBounds(478, 398, 85, 36);
		contentPane.add(btnback);
	}
}
