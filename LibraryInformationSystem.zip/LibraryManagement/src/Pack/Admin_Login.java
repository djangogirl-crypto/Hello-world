package Pack;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class Admin_Login extends JFrame {

	private JPanel contentPane;
	private JTextField text;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Login frame = new Admin_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connect = null;
	/**
	 * Create the frame.
	 */
	public Admin_Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl_Admin = new JLabel("Admin Login");
		lbl_Admin.setFont(new Font("Tahoma", Font.BOLD, 22));
		lbl_Admin.setBounds(218, 28, 152, 34);
		contentPane.add(lbl_Admin);
		
		JLabel lblUserName = new JLabel("Username");
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUserName.setBounds(146, 142, 117, 27);
		contentPane.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPassword.setBounds(146, 227, 117, 27);
		contentPane.add(lblPassword);
		
		text = new JTextField();
		text.setBounds(289, 141, 152, 34);
		contentPane.add(text);
		text.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(289, 226, 152, 34);
		contentPane.add(password);
		
		JButton btnAdminLogin = new JButton("Login");
		btnAdminLogin.setForeground(new Color(255, 255, 255));
		btnAdminLogin.setBackground(new Color(0, 0, 128));
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					connect = Connector.dbConnector();
					String query = "SELECT * FROM admin_login WHERE Admin_ID=? and Admin_Password=?";
					PreparedStatement pst = connect.prepareStatement(query);
					pst.setString(1,text.getText());
					pst.setString(2,password.getText());
					ResultSet rs = pst.executeQuery();
					int count=0;
					while(rs.next())
					{
						count++;
					}
					if(count==1)
					{
						JOptionPane.showMessageDialog(btnAdminLogin,"Username and Password is correct");
						contentPane.invalidate();
						Admin_Block ab = new Admin_Block();
						ab.setVisible(true);
					}
					else if(count>1)
					{
						JOptionPane.showMessageDialog(btnAdminLogin,"Duplicate records are present");
					}
					else
					{
						if(text.getText().isEmpty() || password.getText().isEmpty())
						{
							JOptionPane.showMessageDialog(btnAdminLogin,"Please enter all the fields");
						}
						else {
						JOptionPane.showMessageDialog(btnAdminLogin,"Incorrect Username or Password");
						}
					}
					rs.close();
					pst.close();
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(btnAdminLogin,"Login Failed");
				}
			}
		});
		btnAdminLogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAdminLogin.setBounds(218, 322, 128, 34);
		contentPane.add(btnAdminLogin);
		
		JLabel admin = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/admin-2.png")).getImage();
		admin.setIcon(new ImageIcon(img));
		admin.setBounds(10, 10, 128, 110);
		contentPane.add(admin);
	}
}
