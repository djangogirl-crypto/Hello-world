package Pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Add_Book extends JFrame {

	private JPanel contentPane;
	private JTextField textcallno;
	private JTextField textname;
	private JTextField textauthor;
	private JTextField textpublisher;
	private JTextField textquantity;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Book frame = new Add_Book();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn = null;
	/**
	 * Create the frame.
	 */
	public Add_Book() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650,500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbladdbooks = new JLabel("Add Books");
		lbladdbooks.setFont(new Font("Tahoma", Font.BOLD, 20));
		lbladdbooks.setBounds(240, 10, 129, 35);
		contentPane.add(lbladdbooks);
		
		JLabel lblcallno = new JLabel("Call No");
		lblcallno.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblcallno.setBounds(115, 70, 115, 29);
		contentPane.add(lblcallno);
		
		JLabel lblname = new JLabel("Name");
		lblname.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblname.setBounds(115, 125, 115, 29);
		contentPane.add(lblname);
		
		JLabel lblauthor = new JLabel("Author");
		lblauthor.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblauthor.setBounds(115, 179, 115, 29);
		contentPane.add(lblauthor);
		
		JLabel lblpublisher = new JLabel("Publisher");
		lblpublisher.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblpublisher.setBounds(115, 239, 115, 29);
		contentPane.add(lblpublisher);
		
		JLabel lblquantity = new JLabel("Quantity");
		lblquantity.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblquantity.setBounds(115, 295, 115, 29);
		contentPane.add(lblquantity);
		
		textcallno = new JTextField();
		textcallno.setBounds(240, 67, 155, 29);
		contentPane.add(textcallno);
		textcallno.setColumns(10);
		
		textname = new JTextField();
		textname.setBounds(240, 122, 155, 29);
		contentPane.add(textname);
		textname.setColumns(10);
		
		textauthor = new JTextField();
		textauthor.setBounds(240, 176, 155, 29);
		contentPane.add(textauthor);
		textauthor.setColumns(10);
		
		textpublisher = new JTextField();
		textpublisher.setBounds(240, 236, 155, 29);
		contentPane.add(textpublisher);
		textpublisher.setColumns(10);
		
		textquantity = new JTextField();
		textquantity.setBounds(240, 292, 155, 29);
		contentPane.add(textquantity);
		textquantity.setColumns(10);
		JButton btnaddbook = new JButton("Add Book");
		btnaddbook.setBackground(new Color(0, 0, 128));
		btnaddbook.setForeground(new Color(255, 255, 255));
		btnaddbook.addActionListener(new ActionListener() {
			int count=0;
			int issued=0;
			public void actionPerformed(ActionEvent e) {
				conn=Connector.dbConnector();
				try
				{
					String query = "SELECT * FROM  book_details";
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery(query);
					while(rs.next())
					{
						count++;
					}
					JOptionPane.showMessageDialog(btnaddbook,count+" row/s are present ");
					rs.close();
					st.close();
					conn.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(btnaddbook,"Sorry can't add the book!!");
				}
				finally
				{
					conn=Connector.dbConnector();
					try
					{
						DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
						LocalDateTime now = LocalDateTime.now();
						String query2="INSERT INTO book_details VALUES(?,?,?,?,?,?,?,?)";
						PreparedStatement pst = conn.prepareStatement(query2);
						pst.setInt(1,count+1);
						pst.setString(2,textcallno.getText());
						pst.setString(3,textname.getText());
						pst.setString(4,textauthor.getText());
						pst.setString(5,textpublisher.getText());
						pst.setInt(6,Integer.parseInt(textquantity.getText()));
						pst.setInt(7,issued);
						pst.setString(8,dtf.format(now));
						int count = pst.executeUpdate();
						JOptionPane.showMessageDialog(btnaddbook,count+" book/s added successfully");
						pst.close();
						conn.close();
					}
					catch(Exception e2)
					{
						JOptionPane.showMessageDialog(btnaddbook,"Can't add book");
					}
				}
			}
		});
		btnaddbook.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnaddbook.setBounds(214, 359, 129, 35);
		contentPane.add(btnaddbook);
		
		JButton btnback = new JButton("Back");
		btnback.setBackground(new Color(0, 0, 128));
		btnback.setForeground(new Color(255, 255, 255));
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Librarian_Block lb = new Librarian_Block();
				lb.setVisible(true);
			}
		});
		btnback.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnback.setBounds(471, 394, 91, 35);
		contentPane.add(btnback);
	}

}
