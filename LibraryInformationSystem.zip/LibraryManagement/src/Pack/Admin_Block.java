package Pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Admin_Block extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Block frame = new Admin_Block();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public Admin_Block() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminSection = new JLabel("Admin Section");
		lblAdminSection.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblAdminSection.setBounds(233, 40, 180, 33);
		contentPane.add(lblAdminSection);
		
		JButton btnLibAdd = new JButton("Add Librarian");
		btnLibAdd.setBackground(new Color(0, 0, 128));
		btnLibAdd.setForeground(new Color(255, 255, 255));
		btnLibAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.hide();
				Add_Librarian al = new Add_Librarian();
				al.setVisible(true);
			}
		});
		//btnLibAdd.addActionListener(new ActionListener() {
			
		btnLibAdd.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLibAdd.setBounds(227, 120, 168, 45);
		contentPane.add(btnLibAdd);
		
		JButton btnViewLib = new JButton("View Librarian");
		btnViewLib.setForeground(new Color(255, 255, 255));
		btnViewLib.setBackground(new Color(0, 0, 128));
		btnViewLib.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				View_Librarian vl = new View_Librarian();
				vl.setVisible(true);
			}
		});
		btnViewLib.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewLib.setBounds(227, 196, 168, 45);
		contentPane.add(btnViewLib);
		
		JButton btnLibDel = new JButton("Delete Librarian");
		btnLibDel.setForeground(new Color(255, 255, 255));
		btnLibDel.setBackground(new Color(0, 0, 128));
		btnLibDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Delete_Librarian dl = new Delete_Librarian();
				dl.setVisible(true);
			}
		});
		btnLibDel.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLibDel.setBounds(227, 271, 168, 45);
		contentPane.add(btnLibDel);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.setForeground(new Color(255, 255, 255));
		btnLogout.setBackground(new Color(0, 0, 128));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.invalidate();
				Home h = new Home();
				h.main(null);
			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLogout.setBounds(227, 344, 168, 45);
		contentPane.add(btnLogout);
	}

}
