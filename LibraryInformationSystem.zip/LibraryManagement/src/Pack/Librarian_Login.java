package Pack;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Librarian_Login extends JFrame {

	private JPanel contentPane;
	private JTextField text;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Librarian_Login frame = new Librarian_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connect = null;
	/**
	 * Create the frame.
	 */
	public Librarian_Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl_Librarian = new JLabel("Librarian Login");
		lbl_Librarian.setFont(new Font("Tahoma", Font.BOLD, 20));
		lbl_Librarian.setBounds(223, 33, 160, 29);
		contentPane.add(lbl_Librarian);
		
		JLabel lbluser = new JLabel("UserID");
		lbluser.setFont(new Font("Tahoma", Font.BOLD, 15));
		lbluser.setBounds(129, 149, 77, 35);
		contentPane.add(lbluser);
		
		JLabel lblpass = new JLabel("Password");
		lblpass.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblpass.setBounds(129, 222, 77, 29);
		contentPane.add(lblpass);
		
		text = new JTextField();
		text.setBounds(264, 151, 151, 35);
		contentPane.add(text);
		text.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(264, 216, 151, 35);
		contentPane.add(password);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(0, 0, 128));
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				connect=Connector.dbConnector();
				try {
					connect = Connector.dbConnector();
					String query = "SELECT * FROM librarians WHERE librarian_id=? and librarian_password=?";
					PreparedStatement pst = connect.prepareStatement(query);
					pst.setString(1,text.getText());
					pst.setString(2,password.getText());
					ResultSet rs = pst.executeQuery();
					int count=0;
					while(rs.next())
					{
						count++;
					}
					if(count==1)
					{
						JOptionPane.showMessageDialog(btnLogin,"Username and Password is correct");
						contentPane.invalidate();
						Librarian_Block lb = new Librarian_Block();
						lb.setVisible(true);
					}
					else if(count>1)
					{
						JOptionPane.showMessageDialog(btnLogin,"Duplicate records are present");
					}
					else
					{
						if(text.getText().isEmpty() || password.getText().isEmpty())
						{
							JOptionPane.showMessageDialog(btnLogin,"Please enter all the fields");
						}
						else {
						JOptionPane.showMessageDialog(btnLogin,"Incorrect Username or Password");
						}
					}
					rs.close();
					pst.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(btnLogin,"Login Failed");
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLogin.setBounds(224, 311, 118, 35);
		contentPane.add(btnLogin);
		
		JLabel student = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/student-login.png")).getImage();
		student.setIcon(new ImageIcon(img));
		student.setBounds(10, 22, 133, 106);
		contentPane.add(student);
		
		
	}

}

