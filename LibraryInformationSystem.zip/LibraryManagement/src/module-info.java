module LibraryManagement {
	requires java.sql;
	requires java.desktop;
}